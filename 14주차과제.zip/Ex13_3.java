package org.javaro.lecture;
public class Ex13_3 {
	public static void main(String args []) {
		Dog [] dogcage = new Dog[2];
		Cat [] Catcage = new Cat[3];
		Fox [] Foxcage = new Fox[3];
		Wolf [] Wolfcage = new Wolf[2];
		for(int i = 0; i<dogcage.length; i++) dogcage[i] = new Dog();
		for(int i = 0; i<Catcage.length; i++) Catcage[i] = new Cat();
		for(int i = 0; i<Foxcage.length; i++) Foxcage[i] = new Fox();
		for(int i = 0; i<Wolfcage.length; i++) Wolfcage[i] = new Wolf();
		
		for(int i = 0; i<dogcage.length; i++) dogcage[i].eat();
		for(int i = 0; i<Catcage.length; i++) Catcage[i].eat();
		for(int i = 0; i<Foxcage.length; i++) Foxcage[i].eat();
		for(int i = 0; i<Wolfcage.length; i++) Wolfcage[i].eat();
	}
}
class Fox extends Animal {
	@Override
	void eat() {System.out.println("fox eating");}
}
class Wolf extends Animal {
	@Override
	void eat() {System.out.println("Wolf eating");}
}