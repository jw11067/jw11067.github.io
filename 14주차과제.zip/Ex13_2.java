package org.javaro.lecture;
import java.util.Scanner;
public class Ex13_2 {
public static void main (String argd []) {
	Scanner sc = new Scanner(System.in);
	System.out.println("개:1, 고양이:2 ?");
	int select = sc.nextInt();
	Animal animal;
	if(select == 1) {
		animal = new Dog();
		animal.eat();
	} else if (select == 2) {
		animal = new Cat();
		animal.eat();
	}
	sc.close();
}
}
